# GS Group - From Idea to Impact

A modern, responsive startup website built with Next.js and Tailwind CSS. This website showcases GS Group's innovative approach to transforming ideas into market-leading solutions.

## 🚀 Features

- **Modern Design**: Clean, professional design with blue color scheme
- **Fully Responsive**: Optimized for all devices and screen sizes
- **Fast Performance**: Built with Next.js for optimal loading speeds
- **SEO Optimized**: Proper meta tags and semantic HTML structure
- **Interactive Elements**: Smooth animations and hover effects
- **Contact Form**: Functional contact form for lead generation

## 🛠️ Tech Stack

- **Framework**: Next.js 13.5.1
- **Styling**: Tailwind CSS
- **UI Components**: shadcn/ui
- **Icons**: Lucide React
- **Font**: Inter (Google Fonts)
- **Deployment**: Static export ready for GitHub Pages

## 📦 Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/gs-group-website.git
cd gs-group-website
```

2. Install dependencies:
```bash
npm install
```

3. Run the development server:
```bash
npm run dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser.

## 🚀 Deployment

### GitHub Pages Deployment

This project is configured for static export and can be easily deployed to GitHub Pages:

1. Build the project:
```bash
npm run build
```

2. The static files will be generated in the `out` directory.

3. Push your code to GitHub and enable GitHub Pages in your repository settings.

### Other Deployment Options

- **Vercel**: Connect your GitHub repository to Vercel for automatic deployments
- **Netlify**: Drag and drop the `out` folder to Netlify for instant deployment
- **Any Static Host**: Upload the contents of the `out` folder to any static hosting service

## 📁 Project Structure

```
├── app/
│   ├── globals.css          # Global styles and Tailwind imports
│   ├── layout.tsx           # Root layout with metadata
│   └── page.tsx             # Main page component
├── components/
│   ├── ui/                  # shadcn/ui components
│   ├── About.tsx            # About section component
│   ├── Contact.tsx          # Contact form and info
│   ├── Footer.tsx           # Footer with links and social
│   ├── Hero.tsx             # Hero section with CTA
│   ├── Navigation.tsx       # Header navigation
│   ├── Services.tsx         # Services showcase
│   └── Testimonials.tsx     # Client testimonials
├── lib/
│   └── utils.ts             # Utility functions
└── public/                  # Static assets
```

## 🎨 Customization

### Colors
The website uses a blue color scheme. To change colors, update the Tailwind classes in the components:
- Primary: `blue-600`
- Hover: `blue-700`
- Light: `blue-100`

### Content
Update the content in each component file:
- **Hero**: Edit `components/Hero.tsx`
- **About**: Edit `components/About.tsx`
- **Services**: Edit `components/Services.tsx`
- **Contact**: Edit `components/Contact.tsx`

### Images
Replace the Pexels image URLs with your own images in the respective components.

## 📧 Contact Form

The contact form is currently set up with basic state management. To make it functional:

1. Add a backend API endpoint
2. Integrate with services like:
   - Formspree
   - Netlify Forms
   - EmailJS
   - Custom API

## 🔧 Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run lint` - Run ESLint

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🤝 Contributing

Contributions, issues, and feature requests are welcome! Feel free to check the [issues page](https://github.com/yourusername/gs-group-website/issues).

## 📞 Support

If you have any questions or need help with customization, please open an issue or contact us at hello@gsgroup.com.

---

Built with ❤️ by GS Group